"""
FastAPI serving layer package.
"""
