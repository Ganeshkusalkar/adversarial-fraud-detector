import time
import pickle
import numpy as np
import onnxruntime as ort
from fastapi import FastAPI, HTTPException, Depends
from api.schemas import TransactionInput, FraudPredictionResponse
from src.utils.logger import setup_logger

logger = setup_logger("APIServingGateway")

app = FastAPI(
    title="Adversarial Transaction Disguise Detector API",
    description="FAANG-standard high-throughput inductive GNN fraud detection microservice micro-engine.",
    version="1.0.0"
)

# Global runtime placeholders for thread-safe model execution context sessions
ONNX_SESSION = None
SCALER = None
MODEL_PATH = "artifacts/production/fraud_model.onnx"
SCALER_PATH = "artifacts/production/scaler.pkl"

@app.on_event("startup")
def load_production_artifacts():
    """
    Orchestrates memory allocation caching parameters for compiled model and scaler during startup.
    """
    global ONNX_SESSION, SCALER
    try:
        logger.info(f"Loading compiled execution runtime graph configurations from target path: {MODEL_PATH}")
        # Initialize the optimized ONNX inference runtime session context engine
        ONNX_SESSION = ort.InferenceSession(MODEL_PATH, providers=["CPUExecutionProvider"])
        logger.info("ONNX Runtime Engine Session successfully established in system RAM memory bounds.")
        
        logger.info(f"Loading fitted StandardScaler artifact from: {SCALER_PATH}")
        with open(SCALER_PATH, "rb") as f:
            SCALER = pickle.load(f)
        logger.info("StandardScaler artifact successfully loaded.")
    except Exception as e:
        logger.error(f"Critical System Failure during loading phase lifecycle runtime context creation: {str(e)}")
        ONNX_SESSION = None
        SCALER = None

def get_onnx_session():
    """
    Guarantees request lifecycle isolation context protection dependencies.
    """
    if ONNX_SESSION is None or SCALER is None:
        raise HTTPException(status_code=503, detail="ONNX inference execution pipeline runtime engine or scaler uninitialized.")
    return ONNX_SESSION

@app.post("/api/v1/predict", response_model=FraudPredictionResponse)
async def predict_transaction_risk(payload: TransactionInput, session: ort.InferenceSession = Depends(get_onnx_session)):
    """
    Exposes a unified REST endpoint to parse incoming transaction structures and return real-time fraud decisions.
    """
    start_time = time.time()
    
    try:
        # Step 1: Process and vector-align the unstructured payload input properties
        # Concatenate Vesta features (339 dims) with our custom engineered metrics
        input_vector = np.array(
            payload.vesta_features + [payload.TransactionAmt, payload.C1, payload.C2, payload.D1] + [1.0, 1.0], 
            dtype=np.float32
        ).reshape(1, -1) # Format as shape (1, 345)
        
        # Step 2: Apply StandardScaler scaling to match training feature distributions
        scaled_vector = SCALER.transform(input_vector).astype(np.float32)
        
        # In production environments, mock graph connectivity structures are passed to simulate identity mapping paths
        mock_edges = np.zeros((2, 1), dtype=np.int64) 
        
        # Step 3: Match schema property dictionaries to compilation input signatures
        onnx_inputs = {
            "x": scaled_vector,
            "edge_index": mock_edges
        }
        
        # Step 4: Execute model inference using the optimized ONNX session engine 
        raw_logits = session.run(None, onnx_inputs)[0]
        
        # Step 5: Apply Softmax processing across output matrices to yield standard probabilities
        exp_logits = np.exp(raw_logits - np.max(raw_logits))
        probabilities = exp_logits / exp_logits.sum(axis=-1)
        fraud_probability = float(probabilities[0][1]) # Class 1 = Fraudulent
        
        latency = (time.time() - start_time) * 1000.0 # Convert transaction execution window delta to milliseconds 
        logger.info(f"TxID: {payload.TransactionID} scored securely in {latency:.2f}ms. Fraud Prob: {fraud_probability:.4f}")
        
        return FraudPredictionResponse(
            transaction_id=payload.TransactionID,
            fraud_score=fraud_probability,
            is_fraudulent=fraud_probability >= 0.5, # Flag transaction if it meets or exceeds our decision threshold
            processing_latency_ms=round(latency, 2)
        )
        
    except Exception as e:
        logger.error(f"Error handling single-transaction request event execution lifecycle: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal inference execution pipeline mutation failure: {str(e)}")

@app.get("/health")
async def health_check():
    """
    Exposes an infrastructure monitoring probe interface.
    """
    # Trigger reload indicator (updated)
    return {"status": "healthy", "engine_loaded": ONNX_SESSION is not None}