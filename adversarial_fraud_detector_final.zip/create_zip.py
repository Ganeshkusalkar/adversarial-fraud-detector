import os
import zipfile

def create_zip():
    zip_filename = "adversarial_fraud_detector_final.zip"
    exclude_dirs = {"data", "artifacts", "venv", ".pytest_cache", ".vscode", "__pycache__", ".git"}
    exclude_exts = {".zip", ".pyc"}
    
    print(f"Creating {zip_filename}...")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk("."):
            # Exclude specified directories by modifying dirs in-place
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if any(file.endswith(ext) for ext in exclude_exts):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, ".")
                zipf.write(file_path, arcname)
                
    print(f"Successfully created {zip_filename}")

if __name__ == "__main__":
    create_zip()
