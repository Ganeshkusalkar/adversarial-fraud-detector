"""
Integration tests suite.
"""
