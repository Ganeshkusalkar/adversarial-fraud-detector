"""
Unit tests suite.
"""
