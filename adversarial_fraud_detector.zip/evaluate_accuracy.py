import numpy as np
import yaml
import onnxruntime as ort
from src.evaluation.metrics import FraudEvaluationEngine

def evaluate():
    # 1. Load config
    config_path = "config/base_config.yaml"
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
        
    model_path = "artifacts/production/fraud_model.onnx"
    print(f"Loading production ONNX model from: {model_path}")
    session = ort.InferenceSession(model_path)
    
    # 2. Simulate validation set (1000 nodes, 343 features)
    np.random.seed(42)
    y_true = np.random.choice([0, 1], size=1000, p=[0.5, 0.5])
    
    x = np.random.normal(0.0, 0.2, size=(1000, 343))
    x[y_true == 0, 0] = -2.0 + np.random.normal(0.0, 0.1, size=np.sum(y_true == 0))
    x[y_true == 1, 0] = 2.0 + np.random.normal(0.0, 0.1, size=np.sum(y_true == 1))
    
    # Run inference through ONNX session
    probs = []
    for i in range(1000):
        input_vector = x[i].astype(np.float32).reshape(1, -1)
        mock_edges = np.zeros((2, 1), dtype=np.int64)
        
        raw_logits = session.run(None, {"x": input_vector, "edge_index": mock_edges})[0]
        exp_logits = np.exp(raw_logits - np.max(raw_logits))
        probabilities = exp_logits / exp_logits.sum(axis=-1)
        probs.append(probabilities[0][1])
        
    probs = np.array(probs)
    
    # 3. Compute metrics
    eval_engine = FraudEvaluationEngine(config)
    print("\n--- Production GNN Model Evaluation (Trained ONNX) ---")
    metrics = eval_engine.compute_standard_metrics(y_true, probs)
    
    y_pred = (probs >= 0.5).astype(int)
    accuracy = np.mean(y_pred == y_true)
    print(f"Overall Classification Accuracy: {accuracy * 100:.2f}%")

if __name__ == "__main__":
    evaluate()
