import torch
import torch.nn as nn
from torch_geometric.data import Data
from src.models.discriminator_gnn import FraudGNN
from src.models.generator_lstm import FraudTransactionGenerator
from src.utils.logger import setup_logger

from src.training.losses import FocalLoss

logger = setup_logger("TrainingEngine")

class AdversarialTrainingEngine:
    def __init__(self, gnn_model: FraudGNN, gen_model: FraudTransactionGenerator, device: str = "cpu"):
        """
        Coordinates the training loops between the Attacker (Generator) 
        and Defender (GNN Discriminator) models.
        """
        self.gnn = gnn_model.to(device)
        self.generator = gen_model.to(device)
        self.device = device
        
        # Setup independent FAANG-standard optimizers
        self.opt_D = torch.optim.Adam(self.gnn.parameters(), lr=1e-3)
        self.opt_G = torch.optim.Adam(self.generator.parameters(), lr=1e-4)
        
        # Robust: Focal Loss addressing extreme class imbalance (alpha=0.8 favors fraud class 1)
        self.criterion = FocalLoss(alpha=0.8, gamma=2.0)
        
    def train_epoch(self, real_graph_data: Data, batch_size: int = 64) -> dict:
        """
        Executes one complete epoch of adversarial training.
        """
        real_graph_data = real_graph_data.to(self.device)
        
        # ------------------------------------------------------------------
        # STEP 1: Train Discriminator (GNN Defender)
        # ------------------------------------------------------------------
        self.gnn.train()
        self.generator.eval() # Freeze generator dropout/batchnorm layers
        self.opt_D.zero_grad()
        
        # 1a. Compute loss on genuine historical dataset entries
        real_preds = self.gnn(real_graph_data.x, real_graph_data.edge_index)
        loss_real = self.criterion(real_preds, real_graph_data.y)
        
        # 1b. Synthesize fake transactions and block backpropagation into the generator using .detach()
        noise = self.generator.sample_noise(batch_size, device=self.device)
        synthetic_features = self.generator(noise).detach()
        
        # For structural alignment, we simulate a sub-graph evaluation of adversarial mutations
        # Here we mock the GNN interface over the transformed synthetic transaction block
        mock_edges = torch.zeros((2, batch_size), dtype=torch.long, device=self.device)
        # Pad synthetic features up to match GNN input dimensions
        pad_size = self.gnn.conv1.in_channels - synthetic_features.shape[-1]
        padded_features = torch.cat([synthetic_features[:, 0, :], torch.zeros((batch_size, pad_size), device=self.device)], dim=-1)
        
        fake_preds = self.gnn(padded_features, mock_edges)
        fake_labels = torch.ones(batch_size, dtype=torch.long, device=self.device) # Tell GNN these ARE fraud
        loss_fake = self.criterion(fake_preds, fake_labels)
        
        # Balance and execute backpropagation for the Discriminator
        loss_D = loss_real + (0.5 * loss_fake)
        loss_D.backward()
        self.opt_D.step()
        
        # ------------------------------------------------------------------
        # STEP 2: Train Generator (Attacker Agent) to FOOL the GNN
        # ------------------------------------------------------------------
        self.gnn.eval() # Freeze discriminator updates
        self.generator.train()
        self.opt_G.zero_grad()
        
        # Regenerate adversarial candidate mutations
        noise = self.generator.sample_noise(batch_size, device=self.device)
        synthetic_features = self.generator(noise)
        padded_features = torch.cat([synthetic_features[:, 0, :], torch.zeros((batch_size, pad_size), device=self.device)], dim=-1)
        
        # Run inference through the frozen defender model
        fool_preds = self.gnn(padded_features, mock_edges)
        # The generator's goal is to force the GNN to output 0 (Legitimate) for these fraud samples
        target_labels = torch.zeros(batch_size, dtype=torch.long, device=self.device)
        loss_G = self.criterion(fool_preds, target_labels)
        
        loss_G.backward()
        self.opt_G.step()
        
        return {"discriminator_loss": loss_D.item(), "generator_loss": loss_G.item()}

    def run_training_orchestration(self, real_graph_data: Data, total_epochs: int = 50, batch_size: int = 64):
        """
        Orchestrates multiple rounds of training, tracking model convergence.
        """
        logger.info(f"Starting self-adversarial loop execution for {total_epochs} rounds...")
        for epoch in range(1, total_epochs + 1):
            metrics = self.train_epoch(real_graph_data, batch_size)
            
            if epoch % 10 == 0 or epoch == 1:
                logger.info(
                    f"Epoch [{epoch}/{total_epochs}] | "
                    f"Discriminator Loss: {metrics['discriminator_loss']:.4f} | "
                    f"Generator Loss: {metrics['generator_loss']:.4f}"
                )
        logger.info("Adversarial hardening phase completed successfully.")
