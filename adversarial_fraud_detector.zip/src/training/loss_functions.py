import logging

logger = logging.getLogger(__name__)

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    class nn:
        class Module:
            def __init__(self):
                pass

if HAS_TORCH:
    class FocalLoss(nn.Module):
        """
        Focal Loss implementation for highly imbalanced class distributions.
        FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)
        """
        def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
            super(FocalLoss, self).__init__()
            self.alpha = alpha
            self.gamma = gamma
            self.reduction = reduction

        def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
            """
            inputs: Model logits [batch_size, num_classes]
            targets: True labels [batch_size]
            """
            ce_loss = F.cross_entropy(inputs, targets, reduction='none')
            pt = torch.exp(-ce_loss)
            focal_loss = self.alpha * ((1 - pt) ** self.gamma) * ce_loss
            
            if self.reduction == 'mean':
                return focal_loss.mean()
            elif self.reduction == 'sum':
                return focal_loss.sum()
            return focal_loss

    class AdversarialLoss(nn.Module):
        """
        Loss for training the sequence generator against GNN predictions.
        Forces generated features to produce high legitimate probabilities.
        """
        def __init__(self):
            super(AdversarialLoss, self).__init__()
            
        def forward(self, d_logits: torch.Tensor) -> torch.Tensor:
            # We want to force logits of the fake transactions to look like class 0 (licit)
            # Logits shape: [batch_size, 2] -> target class is all zeros
            targets = torch.zeros(d_logits.size(0), dtype=torch.long, device=d_logits.device)
            return F.cross_entropy(d_logits, targets)
else:
    class FocalLoss(nn.Module):
        """Mock FocalLoss configuration."""
        def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
            super().__init__()
            logger.info("Initializing mock FocalLoss class...")
            
        def forward(self, inputs, targets):
            return 0.0

    class AdversarialLoss(nn.Module):
        """Mock AdversarialLoss configuration."""
        def __init__(self):
            super().__init__()
            logger.info("Initializing mock AdversarialLoss class...")
            
        def forward(self, d_logits):
            return 0.0
