import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):
    """
    Focal Loss to address extreme class imbalance by down-weighting easy-to-classify
    legitimate transactions and forcing gradient focus on hard fraud instances.
    """
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        # Calculate standard cross entropy loss (unreduced)
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        
        # Calculate target class probability p_t
        pt = torch.exp(-ce_loss)
        
        # Calculate dynamic class-weight coefficient alpha_t
        # alpha is applied to positive class (1), 1-alpha to negative class (0)
        alpha_t = torch.where(targets == 1, self.alpha, 1.0 - self.alpha)
        
        # Apply the focal loss scaling factor
        focal_loss = alpha_t * ((1 - pt) ** self.gamma) * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        return focal_loss
