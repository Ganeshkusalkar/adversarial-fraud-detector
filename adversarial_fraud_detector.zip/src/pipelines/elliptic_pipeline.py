import logging
import pandas as pd
import numpy as np
import torch
from typing import Dict, Any, Tuple
from torch_geometric.data import Data
from src.pipelines.base_loader import BaseDataLoader

logger = logging.getLogger(__name__)

class EllipticPipeline(BaseDataLoader):
    """
    Elliptic Bitcoin dataset pipeline. Maps raw transaction nodes and connection edge lists
    into a PyTorch Geometric Data object for GraphSAGE discriminator ingestion.
    """
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.elliptic_config = config['data']['elliptic']

    def load_raw(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Loads features, classes, and edgelist from raw dataset CSV files."""
        features_path = self.elliptic_config['features_path']
        classes_path = self.elliptic_config['classes_path']
        edges_path = self.elliptic_config['edges_path']

        logger.info(f"Loading Elliptic features from: {features_path}")
        features_df = pd.read_csv(features_path, header=None)
        
        logger.info(f"Loading Elliptic classes from: {classes_path}")
        classes_df = pd.read_csv(classes_path)
        
        logger.info(f"Loading Elliptic edges from: {edges_path}")
        edges_df = pd.read_csv(edges_path)
        
        return features_df, classes_df, edges_df

    def preprocess(self, raw_data: Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Map class labels and node IDs to sequential integer indices."""
        features_df, classes_df, edges_df = raw_data
        
        # Map class labels: '1' -> 1 (illicit/fraud), '2' -> 0 (licit/normal), 'unknown' -> -1
        classes_df['label'] = classes_df['class'].map({'1': 1, '2': 0, 'unknown': -1}).fillna(-1).astype(int)
        
        # Create map from txId to sequential node indices
        node_ids = features_df.iloc[:, 0].values
        node_map = {tx_id: idx for idx, tx_id in enumerate(node_ids)}
        
        # Map source and destination IDs in the edgelist to sequential indices
        edges_df['source_idx'] = edges_df['txId1'].map(node_map)
        edges_df['target_idx'] = edges_df['txId2'].map(node_map)
        
        # Drop edges that have unmapped nodes
        edges_df = edges_df.dropna(subset=['source_idx', 'target_idx']).astype(int)
        
        return features_df, classes_df, edges_df

    def extract_features(self, preprocessed_data: Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]) -> Data:
        """Constructs a PyTorch Geometric Data object with node features, edges, and labels."""
        features_df, classes_df, edges_df = preprocessed_data
        
        # Convert node features (ignoring node ID on col 0 and time step on col 1)
        # We skip the first two columns (txId and timestep) to get pure numerical features
        x = torch.tensor(features_df.iloc[:, 2:].values, dtype=torch.float)
        
        # Convert node labels
        y = torch.tensor(classes_df['label'].values, dtype=torch.long)
        
        # Convert edges to edge_index of shape [2, num_edges]
        src_nodes = edges_df['source_idx'].values
        dst_nodes = edges_df['target_idx'].values
        edge_index = torch.tensor([src_nodes, dst_nodes], dtype=torch.long)
        
        # Create PyG Data container
        data = Data(x=x, edge_index=edge_index, y=y)
        
        # Mask only labeled nodes for training/evaluation
        train_mask = (y != -1)
        data.train_mask = train_mask
        
        logger.info(f"Elliptic Graph constructed: Nodes={data.num_nodes}, Edges={data.num_edges}")
        return data

    def run_pipeline(self) -> Data:
        """Orchestrates the entire Elliptic processing pipeline."""
        raw_data = self.load_raw()
        preprocessed = self.preprocess(raw_data)
        graph_data = self.extract_features(preprocessed)
        return graph_data
