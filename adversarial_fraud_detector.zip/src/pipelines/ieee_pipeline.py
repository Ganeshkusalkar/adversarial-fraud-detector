import os
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple
from sklearn.preprocessing import LabelEncoder
from src.pipelines.base_loader import BaseDataLoader
from src.utils.logger import setup_logger

logger = setup_logger("IEEECISPipeline")

class IEEECISPipeline(BaseDataLoader):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.ieee_config = config['data']['ieee']
        self.categorical_cols = config['features']['ieee_categorical']
        self.label_encoders = {}

    def load_raw(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Loads and optimizes memory layout for transaction and identity datasets."""
        tx_path = self.ieee_config['transaction_path']
        id_path = self.ieee_config['identity_path']
        
        logger.info(f"Loading raw IEEE-CIS Transaction data from: {tx_path}")
        df_txn = pd.read_csv(tx_path)
        
        logger.info(f"Loading raw IEEE-CIS Identity data from: {id_path}")
        df_id = pd.read_csv(id_path)
        
        return df_txn, df_id

    def preprocess(self, data: Tuple[pd.DataFrame, pd.DataFrame]) -> pd.DataFrame:
        """Merges transaction and identity metrics, handling sparse signals cleanly."""
        df_txn, df_id = data
        
        logger.info("Executing Left Join on TransactionID...")
        df = pd.merge(df_txn, df_id, on='TransactionID', how='left')
        
        logger.info("Sorting observations chronologically via TransactionDT...")
        df = df.sort_values('TransactionDT').reset_index(drop=True)
        
        logger.info("Imputing sparse V-features while retaining missingness signals...")
        v_cols = [c for c in df.columns if c.startswith('V')]
        
        for col in v_cols:
            if df[col].isnull().sum() > 0:
                # Create an explicit binary indicator flag for missing values 
                df[f'{col}_is_missing'] = df[col].isnull().astype(np.int8)
                # Fill actual NaNs with the median value
                df[col] = df[col].fillna(df[col].median())

        # Process Categorical inputs securely
        logger.info("Encoding categorical variables via LabelEncoder...")
        for col in self.categorical_cols:
            if col in df.columns:
                df[col] = df[col].fillna('UNKNOWN').astype(str)
                le = LabelEncoder()
                df[col] = le.fit_transform(df[col])
                self.label_encoders[col] = le # Cache encoder map for live API execution inference

        # Fill remaining base numeric missing values globally
        num_cols = df.select_dtypes(include=[np.number]).columns
        df[num_cols] = df[num_cols].fillna(df[num_cols].median())
        
        return df

    def extract_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculates fine-grained behavioral interaction velocities and transaction ratios."""
        logger.info("Calculating transactional interaction velocity metrics...")
        
        # Feature 1: Cumulative rolling count of transactions hitting the exact same card entity
        df['card1_count_cumulative'] = df.groupby('card1')['TransactionDT'].transform(
            lambda x: x.expanding().count()
        )
        
        # Feature 2: Value deviation checking against typical spending patterns on this specific card
        card_mean_amt = df.groupby('card1')['TransactionAmt'].transform('mean')
        df['amount_to_mean_ratio'] = df['TransactionAmt'] / (card_mean_amt + 1e-5)
        
        logger.info(f"IEEE-CIS feature extraction completed. Final shape: {df.shape}")
        return df

    def run_pipeline(self) -> pd.DataFrame:
        """Orchestrates the entire execution flow end-to-end."""
        raw_data = self.load_raw()
        preprocessed_df = self.preprocess(raw_data)
        final_featured_df = self.extract_features(preprocessed_df)
        return final_featured_df
