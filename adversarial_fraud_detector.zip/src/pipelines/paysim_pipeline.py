import os
import pandas as pd
import numpy as np
import torch
from typing import Dict, Any, List, Tuple
from src.pipelines.base_loader import BaseDataLoader
from src.utils.logger import setup_logger

logger = setup_logger("PaySimPipeline")

class PaySimPipeline(BaseDataLoader):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.paysim_config = config['data']['paysim']
        self.feature_cols = config['features']['paysim_sequence_features']
        self.sequence_length = config['model']['generator']['sequence_length']

    def load_raw(self) -> pd.DataFrame:
        """Loads the massive PaySim log file from the configured raw directory."""
        path = self.paysim_config['path']
        logger.info(f"Loading raw PaySim logs from: {path}")
        return pd.read_csv(path)

    def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        """Filters the log to relevant operational types and engineers balance signals."""
        logger.info("Filtering dataset to TRANSFER and CASH_OUT types (where fraud occurs)...")
        # Optimization: Fraud in PaySim strictly occurs within these two transaction types
        df = df[df['type'].isin(['TRANSFER', 'CASH_OUT'])].copy()
        df = df.sort_values('step').reset_index(drop=True)

        logger.info("Engineering real-time account balance delta metrics...")
        # Signal 1: Audit if the money moved aligns with the actual sender balance change
        df['orig_balance_diff'] = df['newbalanceOrig'] - df['oldbalanceOrig'] + df['amount']
        
        # Signal 2: Audit if the receiver balance increased by the sent amount
        df['dest_balance_diff'] = df['newbalanceDest'] - df['oldbalanceDest'] - df['amount']
        
        # Signal 3: Binary marker if an account was intentionally wiped completely to zero
        df['orig_zeroed_out'] = (df['newbalanceOrig'] == 0).astype(np.int8)

        return df

    def extract_features(self, df: pd.DataFrame) -> List[Tuple[np.ndarray, int]]:
        """
        Groups transactions chronologically by account to build uniform historical 
        arrays ready for sequence learning models.
        """
        logger.info("Constructing rolling temporal sequence chunks per account...")
        sequences = []
        
        # Group by the source account to track continuous behavioral timelines
        grouped = df.groupby('nameOrig')
        
        for acct, grp in grouped:
            if len(grp) >= self.sequence_length:
                # Ensure correct chronological ordering using the step (hour) tracking metric
                sorted_grp = grp.sort_values('step')
                
                # Extract our target numerical feature matrix
                feature_matrix = sorted_grp[self.feature_cols].values
                
                # Account is classified as fraud if any step in this timeline is flagged malicious
                label = int(sorted_grp['isFraud'].max())
                
                # Chunk long user histories into uniform, configured sequence arrays
                for i in range(0, len(feature_matrix) - self.sequence_length + 1):
                    seq_chunk = feature_matrix[i : i + self.sequence_length]
                    sequences.append((seq_chunk, label))
                    
        logger.info(f"PaySim sequence extraction completed. Total sequences: {len(sequences)}")
        return sequences

    def run_pipeline(self) -> List[Tuple[np.ndarray, int]]:
        """Orchestrates the entire data preparation pipeline flow sequentially."""
        raw_df = self.load_raw()
        processed_df = self.preprocess(raw_df)
        final_sequences = self.extract_features(processed_df)
        return final_sequences
