import torch
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, global_mean_pool
from src.utils.logger import setup_logger

logger = setup_logger("DiscriminatorGNN")

class FraudGNN(torch.nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int = 128, out_channels: int = 2, dropout: float = 0.3):
        """
        Enterprise GraphSAGE network for deep inductive node and graph-level classification.
        
        Args:
            in_channels: Dimension of input node features (Vesta features + engineered metrics).
            hidden_channels: Dimension of hidden structural representations.
            out_channels: Output class count (0 = Legitimate, 1 = Fraudulent).
            dropout: Regularization probability for network stabilization.
        """
        super().__init__()
        logger.info(f"Initializing FraudGNN with Input Dimensions: {in_channels} -> Hidden: {hidden_channels}")
        
        # Layer 1: Captures immediate 1-hop local neighborhood interactions
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        
        # Layer 2: Aggregates 2-hop neighborhood structural signals (catches structural splitting) 
        self.conv2 = SAGEConv(hidden_channels, hidden_channels)
        
        # Layer 3: Aggregates 3-hop contextual patterns (catches complex money loops) 
        self.conv3 = SAGEConv(hidden_channels, hidden_channels // 2)
        
        # Fully Connected Classifier Layer to map embeddings to prediction logits 
        self.classifier = torch.nn.Linear(hidden_channels // 2, out_channels)
        
        self.dropout = torch.nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, batch: torch.Tensor = None) -> torch.Tensor:
        """
        Executes inductive message passing across neighbor nodes and computes fraud scores.
        
        Args:
            x: Node feature matrix tensor.
            edge_index: Graph connectivity matrix graph index map tensor.
            batch: Batch vector array for grouping isolated multi-graph tensors.
        """
        # Step 1: Pass through 1-hop aggregator with ReLU activation and dropout 
        x = F.relu(self.conv1(x, edge_index))
        x = self.dropout(x)
        
        # Step 2: Extract 2-hop graph representations 
        x = F.relu(self.conv2(x, edge_index))
        x = self.dropout(x)
        
        # Step 3: Extract 3-hop macro graph context 
        x = F.relu(self.conv3(x, edge_index))
        
        # Step 4: If processing multiple sub-graphs simultaneously, perform global pooling 
        if batch is not None:
            x = global_mean_pool(x, batch)
            
        # Step 5: Output raw multi-class classification logits 
        return self.classifier(x)
