import os
import yaml
import numpy as np
import pandas as pd
import onnxruntime as ort
from sklearn.preprocessing import StandardScaler
from src.pipelines.ieee_pipeline import IEEECISPipeline

def run_test():
    print("=== Controlled Real Transaction Prediction Test ===")
    
    # 1. Load config
    config_path = "config/base_config.yaml"
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
        
    tx_path = config["data"]["ieee"]["transaction_path"]
    id_path = config["data"]["ieee"]["identity_path"]
    
    # 2. Load and preprocess a subset of real data to extract real in-distribution features
    print("Loading and preprocessing real dataset sample...")
    pipeline = IEEECISPipeline(config)
    def load_raw_subset():
        # Load a large enough subset to get 100 instances of both classes
        df_txn = pd.read_csv(tx_path, nrows=50000)
        df_id = pd.read_csv(id_path)
        return df_txn, df_id
    pipeline.load_raw = load_raw_subset
    processed_df = pipeline.run_pipeline()
    
    # 3. Separate into Licit (Normal) and Illicit (Fraud) sets
    normal_df = processed_df[processed_df['isFraud'] == 0]
    fraud_df = processed_df[processed_df['isFraud'] == 1]
    
    n_normal = 100
    n_fraud = min(100, len(fraud_df))
    
    if len(fraud_df) < 50:
        print(f"Warning: Only found {len(fraud_df)} fraud samples in subset. Adjusting count.")
        
    print(f"Selecting {n_normal} Licit and {n_fraud} Illicit real-world samples...")
    test_df = pd.concat([normal_df.head(n_normal), fraud_df.head(n_fraud)]).reset_index(drop=True)
    ground_truth = test_df['isFraud'].values
    
    # Extract GNN feature columns
    v_features = [f"V{i}" for i in range(1, 340) if f"V{i}" in test_df.columns]
    feature_cols = v_features + config['features']['gnn_node_features'] + ['card1_count_cumulative', 'amount_to_mean_ratio']
    
    features_raw = test_df[feature_cols].values
    
    # CRITICAL FIX: Load the fitted StandardScaler from training to scale the test features.
    # Never call fit_transform on a balanced test set as it leads to covariate/mean shift.
    import pickle
    scaler_path = "artifacts/production/scaler.pkl"
    with open(scaler_path, "rb") as f:
        scaler = pickle.load(f)
    features_scaled = scaler.transform(features_raw)
    
    # 4. Load the trained ONNX model
    model_path = "artifacts/production/fraud_model.onnx"
    print(f"Loading production model: {model_path}")
    session = ort.InferenceSession(model_path)
    
    # 5. Run inference through ONNX session
    predicted_classes = []
    for i in range(len(test_df)):
        input_vector = features_scaled[i].astype(np.float32).reshape(1, -1)
        mock_edges = np.zeros((2, 1), dtype=np.int64)
        
        raw_logits = session.run(None, {"x": input_vector, "edge_index": mock_edges})[0]
        
        exp_logits = np.exp(raw_logits - np.max(raw_logits))
        probs = exp_logits / exp_logits.sum(axis=-1)
        pred_class = probs.argmax(axis=-1)[0]
        predicted_classes.append(pred_class)
        
    predicted_classes = np.array(predicted_classes)
    
    # 6. Calculate confusion matrix counts
    true_negatives = np.sum((ground_truth == 0) & (predicted_classes == 0))
    false_positives = np.sum((ground_truth == 0) & (predicted_classes == 1))
    true_positives = np.sum((ground_truth == 1) & (predicted_classes == 1))
    false_negatives = np.sum((ground_truth == 1) & (predicted_classes == 0))
    
    # 7. Output results
    print("\n--- Ground Truth (Sent to Model) ---")
    print(f"Total Sent:     {len(test_df)}")
    print(f"- Normal:       {n_normal}")
    print(f"- Fraud:        {n_fraud}")
    
    print("\n--- Predictions (Returned by Model) ---")
    print(f"Total Predicted Normal: {true_negatives + false_negatives}")
    print(f"Total Predicted Fraud:  {true_positives + false_positives}")
    
    print("\n--- Confusion Matrix Breakdown ---")
    print(f"[OK] True Negatives (Licit classified as Licit):     {true_negatives} / {n_normal}")
    print(f"[ERR] False Positives (Licit classified as Fraud):   {false_positives} / {n_normal}")
    print(f"[OK] True Positives (Fraud classified as Fraud):     {true_positives} / {n_fraud}")
    print(f"[ERR] False Negatives (Fraud classified as Licit):   {false_negatives} / {n_fraud}")
    
    accuracy = (true_positives + true_negatives) / len(test_df)
    print(f"\nOverall Accuracy on Real Test Batch: {accuracy * 100:.2f}%")

if __name__ == "__main__":
    run_test()
