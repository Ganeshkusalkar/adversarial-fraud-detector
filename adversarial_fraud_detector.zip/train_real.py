import os
import yaml
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from src.pipelines.ieee_pipeline import IEEECISPipeline
from src.graph.graph_builder import TransactionGraphBuilder
from src.models.discriminator_gnn import FraudGNN
from src.evaluation.metrics import FraudEvaluationEngine

def main():
    print("=== Adversarial Transaction Disguise Detector - Real Dataset Training ===")
    
    # 1. Load config
    config_path = "config/base_config.yaml"
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
        
    raw_dir = config["data"]["raw_dir"]
    tx_path = config["data"]["ieee"]["transaction_path"]
    id_path = config["data"]["ieee"]["identity_path"]
    
    if not (os.path.exists(tx_path) and os.path.exists(id_path)):
        print(f"\nERROR: Raw IEEE-CIS dataset files not found!")
        print(f"Please download the train_transaction.csv and train_identity.csv files from Kaggle:")
        print("https://www.kaggle.com/c/ieee-fraud-detection/data")
        print(f"And place them in: {raw_dir}/")
        return
        
    # 2. Run Pipeline
    print("\n[Step 1] Running feature engineering pipeline on real data...")
    pipeline = IEEECISPipeline(config)
    processed_df = pipeline.run_pipeline()
    
    # 3. Build Graph
    print("\n[Step 2] Constructing inductive transaction graph...")
    builder = TransactionGraphBuilder(config)
    graph_data = builder.build_inductive_graph(processed_df)
    
    # 4. Initialize Models
    gnn_config = config["model"]["gnn"]
    model = FraudGNN(
        in_channels=gnn_config["in_channels"],
        hidden_channels=gnn_config["hidden_channels"],
        out_channels=gnn_config["out_channels"],
        dropout=gnn_config["dropout"]
    )
    
    # 5. Run a simple PyTorch training loop on GNN
    print("\n[Step 3] Training GNN on real transaction graph...")
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss(weight=torch.tensor([1.0, 10.0])) # Handle class imbalance
    
    model.train()
    for epoch in range(1, 11):
        optimizer.zero_grad()
        out = model(graph_data.x, graph_data.edge_index)
        loss = criterion(out, graph_data.y)
        loss.backward()
        optimizer.step()
        print(f"Epoch {epoch}/10 | Training Loss: {loss.item():.4f}")
        
    # 6. Evaluate
    print("\n[Step 4] Evaluating trained GNN metrics...")
    model.eval()
    with torch.no_grad():
        logits = model(graph_data.x, graph_data.edge_index)
        probs = torch.softmax(logits, dim=-1)[:, 1].numpy()
        y_true = graph_data.y.numpy()
        
    eval_engine = FraudEvaluationEngine(config)
    eval_engine.compute_standard_metrics(y_true, probs)
    
    # 7. Export to production path
    target_path = "artifacts/production/fraud_model.onnx"
    print(f"\n[Step 5] Exporting real trained GNN to production ONNX path: {target_path}")
    dummy_x = torch.randn(1, gnn_config["in_channels"])
    dummy_edge = torch.zeros((2, 1), dtype=torch.long)
    torch.onnx.export(
        model,
        (dummy_x, dummy_edge),
        target_path,
        input_names=["x", "edge_index"],
        output_names=["output"],
        dynamic_axes={"x": {0: "num_nodes"}, "edge_index": {1: "num_edges"}},
        opset_version=17
    )
    print("Training and export complete!")

if __name__ == "__main__":
    main()
