import logging
import time
import numpy as np
from fastapi import APIRouter, Depends, HTTPException
from ..schemas import TransactionRequest, PredictionResponse
from ..dependencies import get_onnx_session, ONNXInferenceSession

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/predict", tags=["Inference"])

# Track request metrics locally
LATENCY_HISTOGRAM = []
TPS_COUNTER = 0

@router.post("", response_model=PredictionResponse)
def predict_transaction(
    request: TransactionRequest, 
    session: ONNXInferenceSession = Depends(get_onnx_session)
):
    """
    Sub-50ms Inference Endpoint for Real-time Adversarial Fraud Detection.
    Receives incoming transactions, maps local neighborhoods, and scores fraud risk.
    """
    global TPS_COUNTER
    start_time = time.perf_counter()
    TPS_COUNTER += 1
    
    try:
        # Preprocess features
        features = request.features
        if features is None:
            # Construct feature vector from transaction attributes
            features = [
                request.amount,
                request.oldbalanceOrg,
                request.newbalanceOrig,
                request.oldbalanceDest,
                request.newbalanceDest,
                float(request.step)
            ]
            
        # Reshape to meet ONNX signature requirements
        node_features = np.array([features], dtype=np.float32)
        # Mock simple single-node self loop edge index for standalone requests
        edge_index = np.array([[0], [0]], dtype=np.int64)
        
        # Execute ONNX session inference
        risk_score = session.predict(node_features, edge_index)
        
        # 80% risk threshold classification
        flagged = risk_score >= 0.80
        
        latency = (time.perf_counter() - start_time) * 1000.0 # Latency in MS
        LATENCY_HISTOGRAM.append(latency)
        
        # Keep histogram size bounded
        if len(LATENCY_HISTOGRAM) > 1000:
            LATENCY_HISTOGRAM.pop(0)
            
        logger.info(
            "Transaction processed.", 
            extra={
                "extra_fields": {
                    "txId": request.txId,
                    "risk_score": risk_score,
                    "flagged": flagged,
                    "latency_ms": latency
                }
            }
        )
        
        return PredictionResponse(
            txId=request.txId,
            risk_score=risk_score,
            flagged=flagged,
            inference_latency_ms=round(latency, 2)
        )
        
    except Exception as e:
        logger.error(f"Inference pipeline failure: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal GNN Inference Failure")
