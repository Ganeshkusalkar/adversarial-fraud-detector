import os
import yaml
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from src.pipelines.ieee_pipeline import IEEECISPipeline
from src.graph.graph_builder import TransactionGraphBuilder
from src.models.discriminator_gnn import FraudGNN
from src.models.generator_lstm import FraudTransactionGenerator
from src.training.engine import AdversarialTrainingEngine
from src.evaluation.metrics import FraudEvaluationEngine

def main():
    print("=== Training GNN on a Real Subset with ADVERSARIAL ROBUSTNESS (20,000 transactions) ===")
    
    # 1. Load config
    config_path = "config/base_config.yaml"
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
        
    tx_path = config["data"]["ieee"]["transaction_path"]
    id_path = config["data"]["ieee"]["identity_path"]
    
    # 2. Initialize pipeline
    pipeline = IEEECISPipeline(config)
    
    # Override load_raw to load subset
    def load_raw_subset():
        print(f"Loading raw transaction subset: {tx_path} (20,000 rows)...")
        df_txn = pd.read_csv(tx_path, nrows=20000)
        df_id = pd.read_csv(id_path)
        return df_txn, df_id
        
    pipeline.load_raw = load_raw_subset
    
    # Run preprocessing and extraction
    processed_df = pipeline.run_pipeline()
    
    # 3. Build Graph
    builder = TransactionGraphBuilder(config)
    graph_data = builder.build_inductive_graph(processed_df)
    
    # OPTIMIZATION: Fit StandardScaler on x features to normalize distributions!
    # This prevents high-range columns (like TransactionAmt) from exploding the gradients
    import pickle
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(graph_data.x.numpy())
    graph_data.x = torch.tensor(x_scaled, dtype=torch.float)
    
    # Save the scaler artifact
    scaler_path = "artifacts/production/scaler.pkl"
    os.makedirs(os.path.dirname(scaler_path), exist_ok=True)
    with open(scaler_path, "wb") as f:
        pickle.dump(scaler, f)
    print(f"Fitted scaler saved securely to: {scaler_path}")
    
    # 4. Initialize models
    gnn_config = config["model"]["gnn"]
    model = FraudGNN(
        in_channels=gnn_config["in_channels"],
        hidden_channels=gnn_config["hidden_channels"],
        out_channels=gnn_config["out_channels"],
        dropout=gnn_config["dropout"]
    )
    
    gen_config = config["model"]["generator"]
    generator = FraudTransactionGenerator(
        noise_dim=gen_config["noise_dim"],
        hidden_dim=gen_config["hidden_dim"],
        sequence_length=gen_config["sequence_length"],
        feature_dim=gen_config["feature_dim"],
        num_layers=gen_config["num_layers"]
    )
    
    # 5. Initialize the Robust Adversarial Training Engine (utilizing Focal Loss)
    engine = AdversarialTrainingEngine(model, generator, device="cpu")
    
    print("\nTraining GNN & Generator in an adversarial hardening loop (30 epochs)...")
    for epoch in range(1, 31):
        metrics = engine.train_epoch(graph_data, batch_size=64)
        if epoch % 5 == 0 or epoch == 1:
            print(f"Epoch {epoch}/30 | Discriminator Loss: {metrics['discriminator_loss']:.4f} | Generator Loss: {metrics['generator_loss']:.4f}")
        
    # 6. Evaluate
    print("\nEvaluating optimized model...")
    model.eval()
    with torch.no_grad():
        logits = model(graph_data.x, graph_data.edge_index)
        probs = torch.softmax(logits, dim=-1)[:, 1].numpy()
        y_true = graph_data.y.numpy()
        
    eval_engine = FraudEvaluationEngine(config)
    eval_engine.compute_standard_metrics(y_true, probs)
    
    y_pred = (probs >= 0.5).astype(int)
    accuracy = np.mean(y_pred == y_true)
    print(f"Overall Classification Accuracy: {accuracy * 100:.2f}%")
    
    # 7. Export trained GNN to production ONNX
    target_path = "artifacts/production/fraud_model.onnx"
    print(f"\nSaving real-trained model to ONNX: {target_path}")
    dummy_x = torch.randn(1, gnn_config["in_channels"])
    dummy_edge = torch.zeros((2, 1), dtype=torch.long)
    torch.onnx.export(
        model,
        (dummy_x, dummy_edge),
        target_path,
        input_names=["x", "edge_index"],
        output_names=["output"],
        dynamic_axes={"x": {0: "num_nodes"}, "edge_index": {1: "num_edges"}},
        opset_version=17
    )
    print("Real model training and export complete!")

if __name__ == "__main__":
    main()
