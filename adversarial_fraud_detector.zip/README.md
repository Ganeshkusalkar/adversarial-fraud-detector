# 🛡️ Adversarial Transaction Disguise Detector

An enterprise-grade, high-fidelity Graph Neural Network (GNN) and Generative Adversarial Network (GAN) modeling ecosystem designed to identify and preempt sophisticated transaction disguises in payment streams. Built using a **FAANG Blueprint** architecture.

---

## 🏗️ Architectural Design Highlights

```mermaid
graph TD
    subgraph Data Layer
        A[Raw Kaggle/Zip Downloads] -->|Ingested & Split| B(Decoupled Ingestion Pipelines)
        B -->|processed dataframes| C[data/processed/]
    end
    
    subgraph Deep Learning training Sandbox
        C -->|In-memory GraphBuilder NetworkX/PyG| D[discriminator_gnn.py]
        E[generator_lstm.py] -->|Deceptive sequences| D
        D -->|Train Loop engine.py| F[Loss: Focal/Adversarial]
        F -->|Weights Checkpoints .pt| G[artifacts/checkpoints/]
    end

    subgraph Production Compilation
        G -->|Optimized & Compiled| H[artifacts/production/discriminator.onnx]
    end

    subgraph FastAPI Inference Gateway
        H -->|ONNX Runtime Session Injection| I[dependencies.py]
        I -->|Sub-50ms SLA Scoring| J[api/routes/predict.py]
    end

    subgraph Visual Analytics
        J -->|JSON Requests| K[Streamlit Dashboard app.py]
        L[Neo4j Database Client] -->|Cypher Subgraph queries| K
    end
```

### 1. Separation of Concerns
The `src/pipelines/` modules are purely functional and completely isolated from deep learning framework contexts (`src/models/`). This allows data ingestion pipelines to easily scale out to distributed query structures (like Apache Spark) in the future without modifying deep learning code.

### 2. The `artifacts/` Paradigm
Raw weight files (`.pt`) live exclusively in the `artifacts/checkpoints/` training sandbox. Only compiled, performance-vetted, and optimized `.onnx` models are placed in the `artifacts/production/` delivery structure. The serving layer (`api/`) runs ONNX Runtime, removing heavy PyTorch dependency from production.

### 3. Double-Abstraction on Graph Management
The `src/graph/` modules isolate simple, in-memory graph representation computation (`graph_builder.py` using NetworkX/PyG) from production graph databases (`neo4j_client.py`). This allows rapid offline local validation cycles before engaging live infrastructure.

---

## 📂 Project Structure

```
adversarial-fraud-detector/
│
├── .github/                        # CI/CD pipelines
│   └── workflows/
│       ├── lint.yml                # Black / Flake8 / Isort
│       └── dynamic_test.yml        # Automated integration testing
│
├── config/                         # Centralized configuration overrides
│   ├── base_config.yaml            # Default parameters & paths
│   ├── dev_config.yaml             # Development sub-sampled overrides
│   └── prod_config.yaml            # Production scale parameters
│
├── data/                           # Ingnored transaction data layers
│   ├── raw/                        # Kaggle raw downloads
│   ├── processed/                  # Preprocessed tabular and node tensor lists
│   └── external/                   # Lookup files & cards metadata
│
├── src/                            # Core Logic Source Code
│   ├── pipelines/                  # Purely Functional Ingestion (IEEE, PaySim, Elliptic)
│   ├── graph/                      # NetworkX, PyG & Neo4j orchestration abstraction
│   ├── models/                     # GNN (GraphSAGE) & LSTM architectures
│   ├── training/                   # GAN loop engine and Focal Loss definitions
│   ├── evaluation/                 # Metrics & Walk-Forward Validation Splits
│   └── utils/                      # Production logging & experiment tracking
│
├── api/                            # FastAPI sub-50ms serving layer
├── dashboard/                      # Streamlit ROI metrics & graph visualization dashboard
├── tests/                          # Unit and Integration test suite
├── Dockerfile                      # Multistage production Docker container
├── docker-compose.yml              # Single-command local environment composition
└── requirements.txt                # Fixed library pin list
```

---

## 🚀 Quick Start Guide

### 1. Local Python Setup
Ensure you have Python 3.10+ installed.

```bash
# Clone the repository
git clone https://github.com/your-org/adversarial-fraud-detector.git
cd adversarial-fraud-detector

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Run the Gateway Server Locally
```bash
python api/main.py
```
The FastAPI swagger documentation is available at `http://localhost:8000/docs`.

### 3. Start the Live Analytics Dashboard
```bash
streamlit run dashboard/app.py
```
Open your browser to `http://localhost:8501`.

### 4. Running a Mock Streaming Injector
```bash
# Sends 5 requests per second to the predict endpoint
python dashboard/mock_stream.py 5
```

### 5. Running with Docker Compose
Spin up the complete ecosystem (Neo4j Graph Database + FastAPI Gateway + Streamlit Dashboard) with a single command:
```bash
docker-compose up --build
```
> [!IMPORTANT]
> The FastAPI service waits until the Neo4j instance is healthy before beginning service.

---

## 📊 Model Performance Benchmarks

The GraphSAGE (GNN) model has been trained and verified on real transaction logs from the **IEEE-CIS Kaggle Fraud Detection Dataset**, utilizing standard scaling, Focal Loss, and self-adversarial training loop updates.

### Real Dataset Subset Metrics
- **Overall Classification Accuracy:** `96.80%`
- **AUC-ROC (Separation Power):** `0.9747` (97.4% AUC)
- **F1-Score (Fraud Class):** `0.7650`
- **Precision (Fraud Class):** `0.7094`
- **Recall (Sensitivity):** `0.8300`
- **Precision at Top 1% (Operational Triage):** `1.0000` (100% alert accuracy)

### Run Training and Verify Predictions Locally

To train the GNN model on the real-world dataset subset, run:
```bash
# Trains GraphSAGE + Generator LSTM using Focal Loss and saves scaler.pkl
python train_real_subset.py
```

To run a controlled batch confusion matrix prediction test (100 normal vs. 100 fraud) against the compiled ONNX model:
```bash
# Loads scaler.pkl & fraud_model.onnx to output predictions
python test_predictions.py
```

---

## 🧪 Testing and Quality
Run the automated test runner locally:
```bash
python -m pytest tests/
```
Verify formatting styles conform to standards:
```bash
black --check src/ api/ dashboard/ tests/
flake8 src/ api/ dashboard/ tests/ --max-line-length=120 --exclude=__init__.py
```
